var beurt = "X";//variabele voor wie er nu aan de beurt is
var spelBezig = true;//een boolean om te bepalen wanneer het spel bezig is (false tijdens gelijkspel en winnaar)
var zetjes = 0;//een tracker voor hoeveel zetten er zijn gezet

//p1, p2 zijn variabelen voor de 2 input velden voor namen
var p1;
var p2;

//window.onclick is een event dat word geroepen wanneer de gebruiker in het venster klikt (even is een standard argument om muis coordinaten te pakken)
window.onclick = function(event){
    // mX mY zijn muis coordinaten
    var mX = event.clientX;
    var mY = event.clientY;
    
    //hier geven we de variabelen p1 en p2 de waarde van de input velden, omdat ze bij een voortkomend event zijn kunnen ze live geupdated worden
    p1 = document.getElementById("player1").getElementsByTagName("input").item(0).value;
    p2 = document.getElementById("player2").getElementsByTagName("input").item(0).value;
    
    //een dubbele for loop om rij en kollom te pakken van het speelveld
    for(var x = 1; x <= 3; x++){
        for(var y = 1; y<= 3; y++){
            var cel = document.getElementById("r" + x + "k" + y);//we zetten de variabel 'cel' vast aan een waarde van een van de cellen, dit word 9X gedaan omdat ze in een dubbele for loop zitten
            
            //deze if statement controleert in welke cell je muis zich bevind tijdens het klikken, met behulp van een boundingRect object en de muis coordinaten
            if(mY >= cel.getBoundingClientRect().top && mX <= cel.getBoundingClientRect().right && mY <= cel.getBoundingClientRect().bottom && mX >= cel.getBoundingClientRect().left){
                setCellOccupied(cel);//roept de setCellOccupied functie met de gegeven cell die we moeten vullen
                checkGelijkSpel();//daarnaa controleren of iemand al heeft gewonnen
            }
        }
    }
}

//definieer de functie controleerWinnaar (cbeurt staat voor cellbeurt, om te controleren welke cell welke beurt bevat)
function controleerWinaar(cbeurt){
    var winnaar;//een placeholder voor wie de winnaar is
    
    //een if, if else statement om te kijken welke speler aan welke beurt is gebonden, dan geven we de placeholder de waarde van de winnende naam p1 of p2
    if(cbeurt == "X"){
        winnaar = p1;
    }else if(cbeurt == "O"){
        winnaar = p2;
    }
    
    //nog een dubbele for loop 
    for(var x = 1; x <= 3; x++){
        for(var y = 1; y<= 3; y++){
            
            //de komende if, if else statements controleren of er een winnaaar is en op welke wijzen (verticaal horizontaal, schuinrechts, schuinlinks)
            if(document.getElementById("r" + x + "k" + 1).innerHTML == cbeurt && document.getElementById("r" + x + "k" + 2).innerHTML == cbeurt && document.getElementById("r" + x + "k" + 3).innerHTML == cbeurt){
                setWinnerVisible(true, winnaar);
                spelBezig = false;
            }else if(document.getElementById("r" + 1 + "k" + y).innerHTML == cbeurt && document.getElementById("r" + 2 + "k" + y).innerHTML == cbeurt && document.getElementById("r" + 3 + "k" + y).innerHTML == cbeurt){
                setWinnerVisible(true, winnaar);
                spelBezig = false;
            }else if(document.getElementById("r" + 1 + "k" + 1).innerHTML == cbeurt && document.getElementById("r" + 2 + "k" + 2).innerHTML == cbeurt && document.getElementById("r" + 3 + "k" + 3).innerHTML == cbeurt){
                setWinnerVisible(true, winnaar);
                spelBezig = false;
            }else if(document.getElementById("r" + 1 + "k" + 3).innerHTML == cbeurt && document.getElementById("r" + 2 + "k" + 2).innerHTML == cbeurt && document.getElementById("r" + 3 + "k" + 1).innerHTML == cbeurt){
                setWinnerVisible(true, winnaar);   
                spelBezig = false;
            }
            
            //zodra we hebben gewonnen word spelBezig = false, dat betekent dat tijdens het controleren deze if statement af gaat, en het spel na 7 seconden weer verder
            if(!spelBezig){
                setTimeout(nieuwSpel, 7000);//setTimeOut is een standard DOM functie waar je een functie kan roepen met een soort van timer.
            }
        }
    }
}

//deze functie controleert of er gelijkspel is gespeeld
function checkGelijkSpel(){
    //een simpele if statementom te kijken of er 9 zetjes zijn gespeeld, en om te kijekn of het spel nog bezig is.
    if(zetjes >=9 && spelBezig){
        setTieVisible(true);//setTieVisible is om de melding weer te geven, het gegeven argument is om het aan uit te zetten
        setTimeout(nieuwSpel, 7000);//timer een nieuwe spel
        zetjes = 0;//ztjes naar 0 zetten om verder te kunnen spelen
    }
}

function nieuwSpel(){
    for(var x = 1; x <= 3; x++){
        for(var y = 1; y<= 3; y++){
            document.getElementById("r" + x + "k" + y).innerHTML = "";
        }
    }
    document.getElementById("player1").getElementsByTagName("input").item(0).value = "";
    document.getElementById("player2").getElementsByTagName("input").item(0).value = "";    
    setTieVisible(false);
    setWinnerVisible(false, '');
    zetjes = 0;
    beurt = "X";
    spelBezig = true;
}

function botZet(){
    var x = 1;
    var y = 1;
    
    x = Math.floor(Math.random() * 3 + 1);
    y = Math.floor(Math.random() * 3 + 1);
    
    var cell = document.getElementById("r" + x +"k" + y);
    if(cell.innerHTML == ""){
        setCellOccupied(cell);
    }else{
        botZet();
    }
    console.log(x+ ", " + y)
}

function setCellOccupied(cell) {
    if(cell.innerHTML == "" && spelBezig){
        cell.innerHTML = beurt;
        
        zetjes++;
        controleerWinaar(beurt);
                    
        if(cell.innerHTML == "X"){
            cell.style.color="white";
            beurt = "O";
        }else{
            beurt = "X";
            cell.style.color="white";
        }
        
        if(spelBezig &&  beurt != "X"){
            checkGelijkSpel();
            botZet();
        }
    }
}

function setTieVisible(show){
    var tie = document.getElementById("gelijkspel");
    
    tie.style.display = show == true ? "block" : "none";
}

function setWinnerVisible(show, winnerName){
    var winner = document.getElementById("winnaar");
    var winnerSpan = document.getElementById("winner");
    
    winnerSpan.innerHTML = winnerName;
    winner.style.display = show == true ? "block" : "none";
}